/*
 * vim: ts=2:sw=2:expandtab
 *
 */



class Event {
  constructor(type) {
    this.type = type;
  }
}

exports = module.exports = Event;
